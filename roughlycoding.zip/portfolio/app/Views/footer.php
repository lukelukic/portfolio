<footer class="footer-distributed">
     <div class="container">


			<div class="footer-left col-md-6">

        <div class="logo">
          <p class="lead"><a href="<?php echo BASE_URL; ?>"><span>roughly</span><span>Coding.rs</span></a></p>
        </div>

          <p class="footer-company-name col-md-12">

          roughyCoding 2017 | &copy; All Rights Reserved </p>




			</div>

			<div class="footer-right">

				<p class='text-danger'>Contact Us</p>

				<form class="" action="index.html" method="post">
            	 <div class="form-group">
            	   <input type="text" name="mFirstName" value="" placeholder="First Name" class="form-control okvir" id="mFirstName">
            	 </div>
               <div class="form-group">
            	   <input type="text" name="mPhoneNumber" value="" placeholder="Phone Number" class="form-control okvir" id="mPhoneNumber">
            	 </div>
               <div class="form-group">
            	   <input type="text" name="mEmail" value="" placeholder="Email" class="form-control okvir" id="mEmail">
            	 </div>
               <div class="form-group">
            	   <textarea name="mMessage" rows="8" cols="80" class="form-control okvir" placeholder="Your Message" id="mMessage"></textarea>
            	 </div>
               <div class="form-group">
                 <input type="button" name="mSubmit" value="Submit" class=" form-control boja " id="mSubmit">
               </div>
            	</form>
							<div id="feedback">

              </div>

			</div>
		</div>
		</footer>
		<script type="text/javascript" src="<?php echo BASE_URL; ?>files/js/ajax.js">

	 </script>
	</body>

</html>
