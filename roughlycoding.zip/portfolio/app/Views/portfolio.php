

			<!--- Portfolio --->
			<div id="port" class="portfolio-box">
				<div class="container">
					<div class="about-head text-center">
						<h3>latest <span> projects</span></h3>
					</div>

					<div id="portfoliolist">
					<div class="portfolio logo1 mix_all port-big-grid" data-cat="logo" style="display: inline-block; opacity: 1;">
						<div class="portfolio-wrapper">
							<a data-toggle="modal" data-target=".bs-example-modal-md" href="<?php echo BASE_URL; ?>files/images/p2.jpg" class="b-link-stripe b-animate-go  thickbox swipebox">
						     <img alt="slika" class="p-img" src="<?php echo BASE_URL; ?>files/images/p2.jpg" /><div class="b-wrapper"><h2 class="b-animate b-from-left    b-delay03 "><img src="<?php echo BASE_URL; ?>files/images/link-ico.png" alt="plus"/></h2>
						  	</div></a>
		                </div>
					</div>

					<div class="clearfix"> </div>
					<a class="load-ports" href="#">Request Project</a>
				</div>

			</div>
         		<a class="port-down-arrow down-arrow-to scroll" href="#team"><span> </span></a>
         		<span class="port-mouse"> </span>
				</div>

			</div>
			<!--- Portfolio --->

      			<div class="clearfix"> </div>
